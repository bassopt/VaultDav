# VaultDAV + Syncthing Docker Compose Package

This archive contains the complete, production-ready Docker Compose stack for **VaultDAV** and **Syncthing**.

## Prerequisites
- Docker Engine 24+ and Docker Compose v2+
- Ports 8080, 8384, and 22000 available on your host (or adjust in `.env`)

## Quick Start

```bash
# 1. Unzip this package
unzip vaultdav-docker-compose.zip
cd vaultdav-docker-compose

# 2. Review and adjust configuration if needed
cp .env.example .env

# 3. Launch the stack
docker compose up -d --build

# 4. View logs
docker compose logs -f
```

## Service URLs
- **VaultDAV Web App & Management UI**: http://localhost:8080 (or your host IP:8080)
- **WebDAV Endpoint**: http://localhost:8080/dav/
- **Native Syncthing Web GUI**: http://localhost:8384
- **Syncthing Sync Port**: 22000 (TCP/UDP)

## Key Features & Security Architecture
1. **SQLite AES-256-GCM Credential Storage**:
   SQLite is located at `./data/db/vaultdav.sqlite` and stores encrypted credentials (login password, optional TOTP secret, and auto-generated safe WebDAV password).
2. **Unified Username**:
   Your WebDAV username is identical to the login username set during account setup.
3. **Optional TOTP 2FA**:
   2FA is not required during registration; you can enable or disable TOTP anytime from the Account & Security menu.
4. **Unencrypted Host Files**:
   Files stored in `./host_volumes/` remain unencrypted on disk and are mounted directly into both the WebDAV container and the Syncthing container.
5. **No External AI / API Keys Required**:
   Runs completely self-contained and private on your server.
