# VaultDAV + Syncthing Docker Compose Package

This archive contains the complete, ready-to-run Docker Compose stack for **VaultDAV** and **Syncthing**.

## How to Run

```bash
# 1. Unzip the archive into a folder
unzip vaultdav-docker-compose.zip -d vaultdav-docker-compose
cd vaultdav-docker-compose

# 2. Build and start the stack in the background
docker compose up -d --build
```

## Access Endpoints

- **VaultDAV & WebDAV**:
  - Web UI: http://localhost:8080 (or http://0.0.0.0:8080)
  - WebDAV Root Endpoint: http://localhost:8080/dav/
- **Native Syncthing Web GUI**:
  - Web UI: http://localhost:8384
  - Synchronization Port: 22000 (TCP/UDP)

## Architecture

1. **Single `./host_volumes` Mount**:
   `docker-compose.yml` and `.env` only expose the single `./host_volumes` parent folder (`/var/webdav` inside both containers). All subfolders (`documents`, `projects`, `media`, `photos`, `backups`, etc.) live inside `./host_volumes`.
2. **SQLite Used Strictly for Encrypted Credentials**:
   Account passwords, optional TOTP secret, and auto-generated safe WebDAV passwords are stored in `./data/db/vaultdav.sqlite` encrypted with AES-256-GCM.
3. **Unified Username**:
   Your WebDAV username is identical to the login username set during account setup.
4. **Optional TOTP 2FA**:
   2FA can be enabled or disabled at any time from the Account & Security menu on the main dashboard.
