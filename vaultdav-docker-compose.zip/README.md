# VaultDAV + Syncthing Docker Compose Package

This archive contains the complete, ready-to-run Docker Compose stack for **VaultDAV** and **Syncthing**.

## How to Run

```bash
# 1. Unzip the archive into a folder
unzip vaultdav-docker-compose.zip -d vaultdav-docker-compose
cd vaultdav-docker-compose

# 2. Build and start the stack in the background
docker compose up -d --build
```

## Access Endpoints

- **VaultDAV Web App & Admin Dashboard (Port 8080)**:
  - Web UI: http://localhost:8080 (or http://0.0.0.0:8080)
- **RFC 4918 WebDAV Service**:
  - WebDAV Endpoint: http://localhost:8080/dav/ (or http://0.0.0.0:8080/dav/)
- **Native Syncthing Web GUI**:
  - Web UI: http://localhost:8384
  - Synchronization Port: 22000 (TCP/UDP)

## Architecture

1. **Single `./host_volumes` Mount & Shared UID/GID**:
   `docker-compose.yml` and `.env` configure `user: "${PUID:-1000}:${PGID:-1000}"` so folders and files created via WebDAV share the host user's UID and GID without root ownership. No example folders are pre-created.
2. **SQLite Used Strictly for Encrypted Credentials**:
   Account passwords, optional TOTP secret, and auto-generated safe WebDAV passwords are stored in `./data/db/vaultdav.sqlite` encrypted with AES-256-GCM.
3. **Unified Username**:
   Your WebDAV username is identical to the login username set during account setup.
4. **Optional TOTP 2FA**:
   2FA can be enabled or disabled at any time from the Account & Security menu on the main dashboard.
