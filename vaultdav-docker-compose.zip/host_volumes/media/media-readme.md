# MEDIA Folder

Shared unencrypted inside `./host_volumes/media` and bridged between WebDAV and Syncthing.
