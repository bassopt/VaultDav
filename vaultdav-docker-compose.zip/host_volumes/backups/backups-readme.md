# BACKUPS Folder

Shared unencrypted inside `./host_volumes/backups` and bridged between WebDAV and Syncthing.
