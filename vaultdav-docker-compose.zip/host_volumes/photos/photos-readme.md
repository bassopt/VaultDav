# PHOTOS Folder

Shared unencrypted inside `./host_volumes/photos` and bridged between WebDAV and Syncthing.
