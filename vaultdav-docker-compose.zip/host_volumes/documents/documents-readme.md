# DOCUMENTS Folder

Shared unencrypted inside `./host_volumes/documents` and bridged between WebDAV and Syncthing.
