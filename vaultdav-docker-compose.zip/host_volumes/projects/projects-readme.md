# PROJECTS Folder

Shared unencrypted inside `./host_volumes/projects` and bridged between WebDAV and Syncthing.
